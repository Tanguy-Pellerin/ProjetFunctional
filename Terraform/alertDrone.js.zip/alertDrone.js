const aws =  require("aws-sdk");
var ses = new aws.SES({
   region: 'eu-west-1'
});
exports.handler = function(event, context, callback) {
   let message = "";
   event.Records.forEach(function(record) {
      // Kinesis data is base64 encoded so decode here
     message = JSON.parse(new Buffer(record.kinesis.data, 'base64').toString('ascii'));
     //violationCode = record.kinesis.data.violationCode.toString();
     //idDrone = record.kinesis.data.idDrone.toString();
      
      if (message.violationCode=="1") {
         var eParams = {
            Destination: {
               ToAddresses: ["tanguy.pellerin@efrei.net"]
            },
            Message: {
               Body: {
                  Text: {
                     Data:"Alert drone " + message.idDrone + " need assistance! \n"
                  }
               },
               Subject: {
                  Data: "Alert Drone"
               }
            },
            Source: "tanguy.pellerin@efrei.net"
         };    
         var email = ses.sendEmail(eParams, function(err, data) {
            if (err) console.log(err);
            else {
               console.log("===EMAIL SENT===");
               console.log("EMAIL CODE END");
               console.log('EMAIL: ', email);
               context.succeed(event);
               callback(null, "email is send");
            }
         });
      }
      
      //console.log('Decoded payload:', violationCode);
      return JSON.stringify(record.kinesis.data, null, 2)
   });
   
   
};
